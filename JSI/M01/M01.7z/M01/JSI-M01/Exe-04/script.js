var tabela = document.getElementById("tabela");
var maiores = 0, menores = 0;


function addTabela() {
    if ((maiores + menores) >= 10) {
        window.alert("Limite atingido");
        return;
    }
    if (document.getElementById("nome").value.length < 1){
        window.alert("Nome inválido");
        return;
    }
    if (document.getElementById("data").value.length < 1){
        window.alert("Data inválido");
        return;
    }

   let qtdLinhas = tabela.rows.length;
   let linha = tabela.insertRow(qtdLinhas);
   let idade =calcularIdade(document.getElementById("data").value);
   let situacao;

   let celCod      = linha.insertCell(0);
   let celNome      = linha.insertCell(1);
   let celNasc      = linha.insertCell(2);
   let celIdade     = linha.insertCell(3);
   let celStatus    = linha.insertCell(4);



   celCod.innerHTML     = qtdLinhas;
   celNome.innerHTML    = document.getElementById("nome").value;
   celNasc.innerHTML    = document.getElementById("data").value;
   celIdade.innerHTML   = idade;

    if (idade > 17) {
        celStatus.innerHTML  = "Maior de idade";
        maiores ++;
        document.getElementById("maiores").innerHTML = maiores;
    }
    
    if (idade < 18 ) {
        celStatus.innerHTML = "Menor de idade"
        menores ++;
        document.getElementById("menores").innerHTML = menores;
    }


}


function calcularIdade(data) {
    return new Date().getFullYear() - new Date(data).getFullYear();
}