let resp        = document.getElementById("resposta");
let descanso    = document.getElementsByClassName("tela-descanso")[0];
let pergunta    = document.getElementsByClassName("pergunta")[0];


function retorno(parametro) {
  displays(false)
   if (parametro == true) {

     resp.innerHTML = "Parabéns você acertou em cheio!!!";
   }
   else {
    resp.innerHTML = "Sei que você consegue, aperta no botão vai!";
   }
}

function displays(parametro) {
    if (parametro == true) {
        descanso.style.display = "none";
        pergunta.style.display = "flex";
    }
    else {
      descanso.style.display = "block";
      pergunta.style.display = "none";
    }
}