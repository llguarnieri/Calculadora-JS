var priExp = 3 - 2 - 1 + 2 + 1 + 3;
var segExp = (2 * 3) - (4 * 5);
var terExp = (2 + 6) - (3 / (7 * 9));
var quaExp = (3 % 4);

console.log("Expressão: 3 - 2 - 1 + 2 + 1 + 3");
console.log(priExp);
console.log("Expressão: (2 * 3) - (4 * 5)");
console.log(segExp);
console.log("Expressão: (2 + 6) - (3 / (7 * 9))");
console.log(terExp);
console.log("Expressão: (3 % 4) - 8");
console.log(quaExp);

function retornaValores() {
    let pri = document.getElementById("pri-exp").innerHTML = `> Resultado: ${priExp}`;
    let seg = document.getElementById("seg-exp").innerHTML = `> Resultado: ${segExp}`;
    let ter = document.getElementById("ter-exp").innerHTML = `> Resultado: ${terExp}`;
    let qua = document.getElementById("qua-exp").innerHTML = `> Resultado: ${quaExp}`;
}