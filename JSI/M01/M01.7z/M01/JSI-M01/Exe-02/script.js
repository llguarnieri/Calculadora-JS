var nome;
var elemento;

//faz a alteração pelo com auxilio do nabegador
function porPront() {
    desabilitarDisplay(false);
    nome = window.prompt("Digite seu nome");  
    pegarElementoResp();
}

//desabilita o display
function porInput() {
    desabilitarDisplay(true)
    document.getElementById("nome-por-input").focus();
}

function pegarValorInput() {
    nome = document.getElementById("nome-por-input").value;
    pegarElementoResp();
    desabilitarDisplay(false);
}

//pega o elemento e troca os valores
function pegarElementoResp() {
    elemento = document.getElementById("resp");
    elemento.style.cssText = 'color: #a2c11c;'
    + 'border: 2px solid #a2c11c;'
    + 'padding: 10px;'
    + 'box-shadow: 0px 0px 10px 1px #a2c11c;';
elemento.innerHTML = `Bem vindo ${nome}`;
}

//controla desabilitar e habilitar display
function desabilitarDisplay(opcao) {
    let elemento
    if (opcao == true) {
        elemento = document.getElementById("div-por-input");
        elemento.style.cssText = 'display: flex';

        elemento = document.getElementById("btn-input");
        elemento.style.cssText = 'display: none'; 
    } 
    else {
        elemento = document.getElementById("div-por-input");
        elemento.style.cssText = 'display: none';

        elemento = document.getElementById("btn-input");
        elemento.style.cssText = 'display: block'; 
    }
}