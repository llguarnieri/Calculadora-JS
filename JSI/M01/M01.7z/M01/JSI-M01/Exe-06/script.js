let indefinido;
let number  = 10;
let string  = "Luan é dmais!";
let funcao = function nome() { return "Luan Guarnieri"};
let objeto =[1, 10.43, "Luan", true, function a(){return "Funcao em array"}];

function mostrarValores() {
    colocaValor("pri-exp", indefinido);
    colocaValor("seg-exp", number);
    colocaValor("ter-exp", string);
    colocaValor("qua-exp", funcao);
    colocaValor("qui-exp", objeto);
}

function colocaValor(nome, variavel) {
    document.getElementById(nome).innerHTML = `Retorno: ${typeof variavel}`;
    console.log(`Variavel: ${variavel} - tipo recebido: ${typeof variavel}`);
}