
//pega os dados por input
function porInput() {
    resultado("resp-nome-input", "nome-comp", 1);
    resultado("resp-nasc-input", "data-nasc", 2);
    resultado("resp-cpf-input", "cpf", 3);
}

//pega os dados por promt do navegador
function porPromt() {
    let aux;
    aux = window.prompt("Digite o nome completo: ");
        if (aux.length < 1) {
            aux = "Luan Guarnieri";
        }
            document.getElementById("resp-nome-promt").innerHTML = aux;
    
    aux = window.prompt("Digite ano de nascimento: (ano / mes / dia)");
        if (aux.length < 1) {
            aux = "2002/02/14";
        }
        aux = new Date().getFullYear() - new Date(aux).getFullYear();
            document.getElementById("resp-nasc-promt").innerHTML = aux;
    
    aux = window.prompt("Digite o CPF: (000.000.000-00) ");
        if (aux.length < 1) {
            aux = "105.849.349-39";
        }
            document.getElementById("resp-cpf-promt").innerHTML = aux;
}

//faz o retorno
function resultado(retorno, input, parametro) {
    let aux = document.getElementById(retorno);

    if (parametro == 1) {
            let nome = document.getElementById(input).value; 
                if (nome.length < 1) {
                    nome = "Luan Guarnieri";
                }

            aux.innerHTML = nome;
    }

    else if (parametro == 3) {
        let cpf = document.getElementById(input).value;
            if (cpf.length < 1) {
                cpf = "105.849.349-39"
            }
            aux.innerHTML = cpf;
    }
    else {

        let nasc = document.getElementById(input).value;
            if (nasc.length < 1) {
                nasc = "2002/02/14";
            }    

        aux.innerHTML = new Date().getFullYear() - new Date(nasc).getFullYear();
    }
        
}

//controla do display
function display(booleano) {
    if (booleano == true) {
        document.getElementsByClassName("cortina-direita")[0].style.display = "none";
        document.getElementsByClassName("lado-direito")[0].style.display = "flex";
        
       document.getElementsByClassName("lado-esquerdo")[0].style.display = "none";
        document.getElementsByClassName("cortina-esquerda")[0].style.display= "flex";
    }
    else {
        document.getElementsByClassName("cortina-esquerda")[0].style.display= "none";
        document.getElementsByClassName("lado-esquerdo")[0].style.display = "flex";
        
        document.getElementsByClassName("cortina-direita")[0].style.display = "flex";
        document.getElementsByClassName("lado-direito")[0].style.display = "none";
    }
}