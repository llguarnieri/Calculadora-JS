

function calcular() {
    let num1    = document.getElementById("num1").value;
    let num2    = document.getElementById("num2").value;
    let num3    = document.getElementById("num3").value;
    let retorno = document.getElementById("retorno"), soma; 

    num1.cssText = "color: #FD0000";

    if (num1.length < 1 || num2.length < 1 || num3.length < 1) {
        window.alert("Existem campos em branco!");
        return;
    }

    soma = somar(num1,num2,num3);

    retorno.innerHTML = `Soma: ${soma}<br>Média: ${media(soma)}`;

}

//função para soma
function somar(num1, num2, num3) {
    let retorno = +(num1) + +(num2) + +(num3);

    return retorno;
}

//função para a média
function media(numero) {
    return +(numero) / 3; 
}