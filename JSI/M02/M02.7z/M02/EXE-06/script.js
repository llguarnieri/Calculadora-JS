var nome;
var salario;
var receber;
var diasTrabalhados;

const diasMEs = 20;

function validarDados() {
    let nome = document.getElementById("nome").value;
    let dias = document.getElementById("dias").value;
    let salario = document.getElementById("salario").value;

    if (nome.length <= 0) {
        window.alert("Nome do funcionário inválido!");
        return
    }
    if (dias.length <= 0 || dias < 1) {
        window.alert("Dias de trabalho inválido!");
        return
    }
    if (salario.length <= 0 || salario < 0) {
        window.alert("Salário inválido!");
        return
    }

    this.nome = nome;
    this.dias = dias;
    this.salario = salario;

    calcular();

    document.getElementById("retorno").innerHTML = `Funcionário: ${nome} - salário: R$: ${salario}`;
}

function calcular() {
    receber = (salario / diasMEs) * diasTrabalhados;
}




